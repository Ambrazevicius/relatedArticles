<?php 
return [
    'plugin' => [
        'name' => 'Related',
        'description' => 'Get related articles by category',
    ],
    'settings' => [
        'number_posts' => 'How many posts to show?',
    ]
];